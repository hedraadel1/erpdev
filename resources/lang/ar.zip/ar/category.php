<?php 
 return [ 
"categories" => "التصنيفات",
"manage_your_categories" => "إدارة التصنيفات الخاصة بك",
"all_your_categories" => "كل التصنيفات",
"category" => "التصنيف",
"category_name" => "إسم التصنيف",
"code" => "رمز التصنيف",
"add_as_sub_category" => "إضافة إلى التصنيف الفرعي",
"select_parent_category" => "حدد التصنيف الرئيسي",
"added_success" => "تمت إضافة التصنيف بنجاح",
"updated_success" => "تم تحديث التصنيف بنجاح",
"deleted_success" => "تم حذف التصنيف بنجاح",
"add_category" => "إضافة تصنيف",
"edit_category" => "تعديل تصنيف",
];
