<li>
   <a href="#ouput-tax-project-invoice" data-toggle="tab" aria-expanded="true">
       <i class="fa fas fa-arrow-circle-up" aria-hidden="true"></i>
    	@lang('report.output_tax')
   		(@lang('project::lang.project_invoice'))
   </a> 
</li>