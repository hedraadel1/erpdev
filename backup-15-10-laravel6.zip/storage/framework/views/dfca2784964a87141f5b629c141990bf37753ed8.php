<?php $request = app('Illuminate\Http\Request'); ?>

<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/appcss.css'), false); ?>">

</head>


<header id="headerdock">

    <div class="no-print dockpc"
        style="border-bottom: 2px double;margin-bottom: 35px;border-right: 2px double;border-left: 2px double;"
        id="dock-container">
        <div id="dock">

            <div style="margin-left:unset;margin-right:0" class="row">
                <div class="col-sm-3">

                    <button class="button-30" href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
						<?php if(Module::has('Essentials')): ?>

						<a  type="button" class=" btn btn-sm clock_in_btn <?php if(!empty($clock_in)): ?> hide <?php endif; ?> "
						data-type="clock_in" data-toggle="tooltip" data-placement="bottom"
						title="<?php echo app('translator')->get('essentials::lang.clock_in'); ?>">
						<i class="fas fa-arrow-circle-down"></i>
					</a>

					<a type="button" class="btn btn-sm clock_out_btn <?php if(empty($clock_in)): ?> hide <?php endif; ?> "
						data-type="clock_out" data-toggle="tooltip" data-placement="bottom" data-html="true"
						title="<?php echo app('translator')->get('essentials::lang.clock_out'); ?> <?php if(!empty($clock_in)): ?> <br>
							<small>
								<b><?php echo app('translator')->get('essentials::lang.clocked_in_at'); ?>:</b> <?php echo e(\Carbon::createFromTimestamp(strtotime($clock_in->clock_in_time))->format(session('business.date_format') . ' ' . 'h:i A'), false); ?>

							</small>
							<br>
							<small><b><?php echo app('translator')->get('essentials::lang.shift'); ?>:</b> <?php echo e(ucfirst($clock_in->shift_name), false); ?></small>
							<?php if(!empty($clock_in->start_time) && !empty($clock_in->end_time)): ?>
								<br>
								<small>
									<b><?php echo app('translator')->get('restaurant.start_time'); ?>:</b> <?php echo e(\Carbon::createFromTimestamp(strtotime($clock_in->start_time))->format('h:i A'), false); ?><br>
									<b><?php echo app('translator')->get('restaurant.end_time'); ?>:</b> <?php echo e(\Carbon::createFromTimestamp(strtotime($clock_in->end_time))->format('h:i A'), false); ?>

								</small> <?php endif; ?>
						<?php endif; ?>">
						<i class="fas fa-hourglass-half fa-spin"></i>
					</a>
					<?php endif; ?>
						<?php echo e(\Carbon::createFromTimestamp(strtotime('now'))->format(session('business.date_format')), false); ?>

					</button>
                </div>


                <div class="col-sm-6">
                    <ul style="padding-top: 7px;">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.dock_products'); ?>" style="margin-right: 2px;margin-left: 2px;">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_products'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.dock_products'); ?>" href="<?php echo e(action('ProductController@index'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/dockbar/products.png'), false); ?> /></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('all_expense.access')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.list_expenses'); ?>" style="margin-right: 2px;margin-left: 2px;">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.list_expenses'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.list_expenses'); ?>" href="<?php echo e(action('ExpenseController@index'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/expense64.png'), false); ?> /></a>
                            </li style="margin-right: 2px;margin-left: 2px;">
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sell.view')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.all_sales'); ?>">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_sales'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.all_sales'); ?>" href="<?php echo e(action('SellController@index'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/dockbar/sales.png'), false); ?> /></a>
                            </li style="margin-right: 2px;margin-left: 2px;">
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('business_settings.access')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.business_settings'); ?>" style="margin-right: 2px;margin-left: 2px;">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.business_settings'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.business_settings'); ?>" href="<?php echo e(action('BusinessController@getBusinessSettings'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/settings.png'), false); ?> /></a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase.view')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.dock_purchase'); ?>" style="margin-right: 2px;margin-left: 2px;">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_purchase'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.dock_purchase'); ?>" href="<?php echo e(action('PurchaseController@index'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/dockbar/purchase.png'), false); ?> /></a>
                            </li>
                        <?php endif; ?>

                        <?php
                            $all_notifications = auth()->user()->notifications;
                            $unread_notifications = $all_notifications->where('read_at', null);
                            $total_unread = count($unread_notifications);
                        ?>

                        <li style="margin-right: 2px;margin-left: 2px;" class="dropdown notifications-menu">
                            <a href="#" class="dropdown-toggle load_notifications" data-toggle="dropdown"
                                id="show_unread_notifications" data-loaded="false">
                                <img src=<?php echo e(asset('/images/icons/dockbar/notification.png'), false); ?> />

                                <span
                                    style="display: unset;position: unset;bottom: unset;left: unset;width: unset;background-color: unset;padding: unset;"
                                    class=" label-warning notifications_count">
                                    <?php if(!empty($total_unread)): ?>
                                        <?php echo e($total_unread, false); ?>

                                    <?php endif; ?>
                                </span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- <li class="header">You have 10 unread notifications</li> -->
                                <li>
                                    <!-- inner menu: contains the actual data -->

                                    <ul style="width: 250px;padding: 10px;" class="menu" id="notifications_list">
                                        <span class="notif-info"
                                            style="display: unset;position: unset;bottom: unset;left: unset;width: unset;background-color: unset;padding: unset;">

                                        </span>
                                    </ul>
                                </li>

                                <?php if(count($all_notifications) > 10): ?>
                                    <li class="footer load_more_li">
                                        <a href="#" class="load_more_notifications"><?php echo app('translator')->get('lang_v1.load_more'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>






                    </ul>
                </div>
                <div class="col-sm-3">
                    <?php if(in_array('pos_sale', $enabled_modules)): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sell.create')): ?>
                            <a href="<?php echo e(action('SellPosController@create'), false); ?>" title="<?php echo app('translator')->get('sale.pos_sale'); ?>"
                                data-toggle="tooltip" data-placement="bottom" class="button-30">
                                <strong> <?php echo app('translator')->get('lang_v1.dock_pos'); ?> <i class="fa fa-th-large"></i> &nbsp;</strong>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>


    <div class="no-print" style="z-index: 1030;" id="dock-statusbar">
        <div class="row">
            <div class="col-sm-4">
                <div id="dock">
                    <li>
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_menu'); ?></span>
                        <a onclick="topFunction()" href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"><img
                                src=<?php echo e(asset('/images/icons/dockbar/menu.png'), false); ?> /></a>
                    </li>
                    <li>
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_up'); ?></span>
                        <a href="#"><img style="margin-top: 2px;"
                                src=<?php echo e(asset('/images/icons/dockbar/up.png'), false); ?> /></a>
                    </li>
				</li>
				<li>
					<span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_howto'); ?></span>
					<a href="<?php echo e(action('BusinessController@howto'), false); ?>"><img
							src=<?php echo e(asset('/images/icons/dockbar/howto.png'), false); ?> /></a>
				</li>

                    <li style="">
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_calendar'); ?></span>
                        <a href="<?php echo e(route('calendar'), false); ?>"><img style="margin-top: 2px;"
                                src=<?php echo e(asset('/images/icons/dockbar/todo.png'), false); ?> /></a>
                    </li>
                    <li style="">
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_Tasks'); ?></span>
                        <a href="#" class="btn-modal"
                            data-href="<?php echo e(action('\Modules\Essentials\Http\Controllers\ToDoController@create'), false); ?>"
                            data-container="#task_modal"><img style="margin-top: 2px;"
                                src=<?php echo e(asset('/images/icons/dockbar/task.png'), false); ?> /></a>
                    </li>

					<li onclick="hideheader()" id="hideall">
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_Hide'); ?></span>
                        <a href="#" id="view_todays_profit"><img style="margin-top: 2px;"
                                src=<?php echo e(asset('/images/icons/dockbar/hideicon.png'), false); ?> /></a>
                    </li>

                </div>
            </div>



            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-4">
                        <div style="" class="">
                            <a href="<?php echo e(action('HomeController@index'), false); ?>"><img
                                    style="margin-top: 2px;animation: wiggle 2s linear infinite;"
                                    src=<?php echo e(asset('/images/icons/dockbar/letter-b.png'), false); ?> />
                                <?php if(Module::has('Superadmin')): ?>
                                    <?php if ($__env->exists('superadmin::layouts.partials.active_subscription')) echo $__env->make('superadmin::layouts.partials.active_subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div style="" class=" containerbtn">

                            <a href="<?php echo e(action('UserController@getProfile'), false); ?>"
                                style="width: 150px !important;margin-top: 3px;" class="buttonBlue">
                                <span class="dock-containerspan">

                                    <?php echo e(Auth::User()->first_name, false); ?> <?php echo e(Auth::User()->last_name, false); ?>

                                </span>
                            </a>

                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div style="" class="">
                            <a href="<?php echo e(action('HomeController@index'), false); ?>"><img
                                    style="margin-top: 2px;animation: wiggle 2s linear infinite;"
                                    src=<?php echo e(asset('/images/icons/dockbar/letter-b.png'), false); ?> /></a>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-sm-4">
                <div class="">



                    <li>
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_suppliers'); ?></span>
                        <a href="<?php echo e(action('ContactController@index', ['type' => 'supplier']), false); ?>"><img
                                src=<?php echo e(asset('/images/icons/dockbar/client.png'), false); ?> /></a>
                    </li>
                    <li>
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_clients'); ?></span>
                        <a href="<?php echo e(action('ContactController@index', ['type' => 'customer']), false); ?>"><img
                                src=<?php echo e(asset('/images/icons/dockbar/supplier.png'), false); ?> /></a>
                    </li>
                    <li>
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_users'); ?></span>
                        <a href="<?php echo e(action('ManageUserController@index'), false); ?>"><img
                                src=<?php echo e(asset('/images/icons/dockbar/users.png'), false); ?> /></a>
                    </li>

					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('business_settings.access')): ?>
					<li title="<?php echo app('translator')->get('lang_v1.RightClick_BassicSetting'); ?>" style="margin-right: 2px;margin-left: 2px;">
						<span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.RightClick_BassicSetting'); ?></span>
						<a title="<?php echo app('translator')->get('lang_v1.RightClick_BassicSetting'); ?>" href="<?php echo e(action('BusinessController@getbasicBusinessSettings'), false); ?>"><img
								src=<?php echo e(asset('/images/icons/dockbar/basicsetting.png'), false); ?> /></a>
					</li>
				<?php endif; ?>

				<li title="<?php echo app('translator')->get('lang_v1.profile'); ?>" style="margin-right: 2px;margin-left: 2px;">
					<span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.profile'); ?></span>
					<a title="<?php echo app('translator')->get('lang_v1.profile'); ?>" href="<?php echo e(action('UserController@getProfile'), false); ?>"><img
							src=<?php echo e(asset('/images/icons/dockbar/profile.png'), false); ?> /></a>
				</li>



                    <li>
                        <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_logout'); ?></span>
                        <a href="<?php echo e(action('Auth\LoginController@logout'), false); ?>"><img style="margin-top: 2px;"
                                src=<?php echo e(asset('/images/icons/dockbar/logout.png'), false); ?> /></a>
                    </li>

                </div>
            </div>
        </div>


    </div>


</header>

<script>
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}
	function hideheader() {
            document.getElementById("headerdock").style.display = "none";
        }
</script>
<?php /**PATH /home/onoo/public_html/erpdev/resources/views/layouts/partials/docker.blade.php ENDPATH**/ ?>