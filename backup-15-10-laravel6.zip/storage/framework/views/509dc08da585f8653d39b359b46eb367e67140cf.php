<?php $request = app('Illuminate\Http\Request'); ?>

<?php if($request->segment(1) == 'pos' && ($request->segment(2) == 'create' || $request->segment(3) == 'edit')): ?>
    <?php
        $pos_layout = true;
    ?>
<?php else: ?>
    <?php
        $pos_layout = false;
		$is_mobile = isMobile();
    ?>
<?php endif; ?>

<?php
    $whitelist = ['127.0.0.1', '::1'];
?>

<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale(), false); ?>" dir="<?php echo e(in_array(session()->get('user.language', config('app.locale')), config('constants.langs_rtl')) ? 'rtl' : 'ltr', false); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<script src="<?php echo e(asset('js/vendor/modernizr-2.6.2.min.js'), false); ?>"></script>
		<link rel="stylesheet" href="<?php echo e(asset('css/main.css'), false); ?>">


        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(Session::get('business.name'), false); ?></title>

        <?php echo $__env->make('layouts.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('css'); ?>

		<style>

.context-menu {
   list-style: none;
   z-index: 999999;
  position: absolute;
  font-size: 17px;
    font-weight: 900;
}
.menu {
  display: flex;
  flex-direction: column;
  background: darkgray;
  border-radius: 10px;
  box-shadow: 0 10px 20px rgb(64 64 64 / 5%);
  padding: 10px 0;
  -webkit-animation: fadeIn 0.1s ease-out;
  animation: fadeIn 0.5s ease-out;
  opacity:1.0;
  display:block;
  width: 250px;
}
.menu > li > a {
  font: 'droid';
  border: 0;
font-style: 'droid';
padding: 2px 30px 2px 15px;
  width: 100%;
  display: flex;
  align-items: center;
  position: relative;
  text-decoration: unset;
  color: #000;
  font-weight: 500;
  transition: 0.5s linear;
  -webkit-transition: 0.5s linear;
  -moz-transition: 0.5s linear;
  -ms-transition: 0.5s linear;
  -o-transition: 0.5s linear;
}
.menu > li > a:hover {
  background:#f1f3f7;
  color: #4b00ff;
}
.menu > li {
	display: unset;
}
.menu > li > a > i {
  padding-right: 10px;
}
.menu > li.trash > a:hover {
  color: red;
}

/* Animatinons */
@-webkit-keyframes fadeIn {
    from {opacity: 0;}
    to {opacity: 1.0;}
}

@keyframes  fadeIn {
    from {opacity: 0;}
    to {opacity: 1.0;}
}
@-webkit-keyframes fadeOut {
    from {opacity: 1.0;}
    to {opacity: 0.0;}
}

@keyframes  fadeOut {
    from {opacity: 1.0;}
    to {opacity: 0.0;}
}

.is-fadingIn {
  -webkit-animation: fadeIn 0.1s ease-out;
  animation: fadeIn 0.1s ease-out;
  opacity:1.0;
  display:block;
}
.is-fadingOut {
  -webkit-animation: fadeOut 0.1s ease-out;
  animation: fadeOut 0.1s ease-out;
  opacity:0.0;
  display:block;
}
		</style>
    </head>

    <body class="<?php if($pos_layout): ?> hold-transition lockscreen <?php else: ?> hold-transition skin-<?php if(!empty(session('business.theme_color'))): ?><?php echo e(session('business.theme_color'), false); ?><?php else: ?><?php echo e('blue-light', false); ?><?php endif; ?> sidebar-mini <?php endif; ?>">
<!--Start of Tawk.to Script-->

    <!--End of Tawk.to Script-->
		<div id="contextMenu" class="context-menu" style="display: none">
			<ul class="menu">
				<li class="share"><a href="<?php echo e(action('HomeController@index'), false); ?>"><?php echo app('translator')->get('lang_v1.Rightclick_Home'); ?> </a></li>

				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sell.create')): ?>
				<li >
					<a  href="<?php echo e(action('SellController@create'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_add_sale'); ?></a>
				</li>
		    	<?php endif; ?>

				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.create')): ?>
				<li >
					<a  href="<?php echo e(action('ProductController@create'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_AddProduct'); ?></a>
				</li>
		    	<?php endif; ?>

				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase.create')): ?>
				<li >
					<a  href="<?php echo e(action('PurchaseController@create'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_purchasecreate'); ?></a>
				</li>
		    	<?php endif; ?>

				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense.add')): ?>
				<li >
					<a  href="<?php echo e(action('ExpenseController@create'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_add_expense'); ?></a>
				</li>
		    	<?php endif; ?>


				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.view')): ?>
				<li >
					<a  href="<?php echo e(action('ContactController@index', ['type' => 'customer']), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_ManageClient'); ?></a>
				</li>
		    	<?php endif; ?>

				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.create')): ?>
				<li >
					<a  href="<?php echo e(action('ContactController@index', ['type' => 'supplier']), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_ManageSupplier'); ?></a>
				</li>
		    	<?php endif; ?>
				
				<li class="link"><a href="#">--------------------------------</a></li>
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('business_settings.access')): ?>
				<li class="copy"><a href="<?php echo e(action('BusinessController@getBusinessSettings'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_Setting'); ?></a></li>
				<li class="copy"><a href="<?php echo e(action('BusinessController@getbasicBusinessSettings'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_BassicSetting'); ?></a></li>

				<?php endif; ?>
				<li class="paste"><a href="https://www.onoo.pro/support/public"><?php echo app('translator')->get('lang_v1.RightClick_Support'); ?></a></li>
				<li class="download"><a  href="<?php echo e(action('UserController@getProfile'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_ManageProfile'); ?></a></li>
				<li class="trash"><a href="<?php echo e(action('Auth\LoginController@logout'), false); ?>"><?php echo app('translator')->get('lang_v1.RightClick_Logout'); ?></a></li>
			</ul>
		</div>


        <div class="wrapper thetop">
            <script type="text/javascript">
                if(localStorage.getItem("upos_sidebar_collapse") == 'true'){
                    var body = document.getElementsByTagName("body")[0];
                    body.className += " sidebar-collapse";
                }
            </script>
              <?php if(!$pos_layout): ?>

			  <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			  <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


			  <?php else: ?>
                <?php echo $__env->make('layouts.partials.header-pos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(in_array($_SERVER['REMOTE_ADDR'], $whitelist)): ?>
                <input type="hidden" id="__is_localhost" value="true">
            <?php endif; ?>

            <!-- Content Wrapper. Contains page content -->
            <div class="<?php if(!$pos_layout): ?> content-wrapper <?php endif; ?>">
                <!-- empty div for vuejs -->
                <div id="app">
                    <?php echo $__env->yieldContent('vue'); ?>
                </div>
                <!-- Add currency related field-->
                <input type="hidden" id="__code" value="<?php echo e(session('currency')['code'], false); ?>">
                <input type="hidden" id="__symbol" value="<?php echo e(session('currency')['symbol'], false); ?>">
                <input type="hidden" id="__thousand" value="<?php echo e(session('currency')['thousand_separator'], false); ?>">
                <input type="hidden" id="__decimal" value="<?php echo e(session('currency')['decimal_separator'], false); ?>">
                <input type="hidden" id="__symbol_placement" value="<?php echo e(session('business.currency_symbol_placement'), false); ?>">
                <input type="hidden" id="__precision" value="<?php echo e(session('business.currency_precision', 2), false); ?>">
                <input type="hidden" id="__quantity_precision" value="<?php echo e(session('business.quantity_precision', 2), false); ?>">
                <!-- End of currency related field-->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_export_buttons')): ?>
                    <input type="hidden" id="view_export_buttons">
                <?php endif; ?>
                <?php if(isMobile()): ?>
                    <input type="hidden" id="__is_mobile">
                <?php endif; ?>
                <?php if(session('status')): ?>
                    <input type="hidden" id="status_span" data-status="<?php echo e(session('status.success'), false); ?>" data-msg="<?php echo e(session('status.msg'), false); ?>">
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>

                <div class='scrolltop no-print'>
                    <div class='scroll icon'><i class="fas fa-angle-up"></i></div>
                </div>

                <?php if(config('constants.iraqi_selling_price_adjustment')): ?>
                    <input type="hidden" id="iraqi_selling_price_adjustment">
                <?php endif; ?>

                <!-- This will be printed -->
                <section class="invoice print_section" id="receipt_section">
                </section>

            </div>
            <?php echo $__env->make('home.todays_profit_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /.content-wrapper -->

            <?php if(!$pos_layout): ?>
            <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php if(isMobile()): ?>
			<?php echo $__env->make('layouts.partials.dockermobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php else: ?>
			<?php echo $__env->make('layouts.partials.docker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		  <?php endif; ?>

            
            <?php endif; ?>

            <audio id="success-audio">
              <source src="<?php echo e(asset('/audio/success.ogg?v=' . $asset_v), false); ?>" type="audio/ogg">
              <source src="<?php echo e(asset('/audio/success.mp3?v=' . $asset_v), false); ?>" type="audio/mpeg">
            </audio>
            <audio id="error-audio">
              <source src="<?php echo e(asset('/audio/error.ogg?v=' . $asset_v), false); ?>" type="audio/ogg">
              <source src="<?php echo e(asset('/audio/error.mp3?v=' . $asset_v), false); ?>" type="audio/mpeg">
            </audio>
            <audio id="warning-audio">
              <source src="<?php echo e(asset('/audio/warning.ogg?v=' . $asset_v), false); ?>" type="audio/ogg">
              <source src="<?php echo e(asset('/audio/warning.mp3?v=' . $asset_v), false); ?>" type="audio/mpeg">
            </audio>
        </div>

        <?php if(!empty($__additional_html)): ?>
            <?php echo $__additional_html; ?>

        <?php endif; ?>

        <?php echo $__env->make('layouts.partials.javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="modal fade view_modal" tabindex="-1" role="dialog"
        aria-labelledby="gridSystemModalLabel"></div>

        <?php if(!empty($__additional_views) && is_array($__additional_views)): ?>
            <?php $__currentLoopData = $__additional_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional_view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if ($__env->exists($additional_view)) echo $__env->make($additional_view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

 <script type="text/javascript">

document.onclick = hideMenu;
       document.oncontextmenu = rightClick;

        function hideMenu() {
            document.getElementById("contextMenu")
                    .style.display = "none"
					$('#contextmenu').addClass('is-fadingOut');
        }

        function rightClick(e) {
            e.preventDefault();

            if (document.getElementById("contextMenu") .style.display == "block"){
                hideMenu();
            }else{
                var menu = document.getElementById("contextMenu")
                menu.style.display = 'block';
                menu.style.left = e.pageX + "px";
                menu.style.top = e.pageY + "px";
				$('#contextmenu').addClass('is-fadingIn');
            }
        }



</script>
<script src="<?php echo e(asset('js/main.js'), false); ?>"></script>


    </body>

</html>
<?php /**PATH /home/onoo/public_html/erpdev/resources/views/layouts/app.blade.php ENDPATH**/ ?>