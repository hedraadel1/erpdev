<?php $request = app('Illuminate\Http\Request'); ?>
<!-- Main Header -->
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/appcss.css'), false); ?>">

</head>
  <header class="main-header no-print">
    <a href="<?php echo e(route('home'), false); ?>" class="logo">
      <span class="logo-lg"><?php echo e(Session::get('business.name'), false); ?> <i class="fa fa-circle text-success" id="online_indicator"></i></span>
    </a>

    <!-- Header Navbar -->
    <nav class="" role="">


      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">

		<div class="no-print dockmobile"
        style="border-bottom: 2px double;margin-bottom: 35px;border-right: 2px double;border-left: 2px double;"
        id="dock-container">
        <div style="" id="dock">

            <div style="margin-left:unset;margin-right:0" class="row">





				</div>


                <div class="col-sm-6">

                    <ul style="padding-top: 7px;padding-right: 5px;">
						<li title="<?php echo app('translator')->get('lang_v1.dock_products'); ?>"  style="margin-right: 2px;margin-left: 2px;">
							<span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_menu'); ?></span>
							<a onclick="topFunction()" style="float: unset !important;display: unset !important;" href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"><img
									src=<?php echo e(asset('/images/icons/dockbar/menu.png'), false); ?> /></a>
						</li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.dock_products'); ?>" style="margin-right: 2px;margin-left: 2px;">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.dock_products'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.dock_products'); ?>" href="<?php echo e(action('ProductController@index'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/dockbar/products.png'), false); ?> /></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('all_expense.access')): ?>
                            <li title="<?php echo app('translator')->get('lang_v1.list_expenses'); ?>" style="margin-right: 2px;margin-left: 2px;">
                                <span class="dock-containerspan"><?php echo app('translator')->get('lang_v1.list_expenses'); ?></span>
                                <a title="<?php echo app('translator')->get('lang_v1.list_expenses'); ?>" href="<?php echo e(action('ExpenseController@index'), false); ?>"><img
                                        src=<?php echo e(asset('/images/icons/expense64.png'), false); ?> /></a>
                            </li style="margin-right: 2px;margin-left: 2px;">
                        <?php endif; ?>




                        <?php
                            $all_notifications = auth()->user()->notifications;
                            $unread_notifications = $all_notifications->where('read_at', null);
                            $total_unread = count($unread_notifications);
                        ?>

                        <li style="margin-right: 2px;margin-left: 2px;" class="dropdown notifications-menu">
                            <a href="#" class="dropdown-toggle load_notifications" data-toggle="dropdown"
                                id="show_unread_notifications" data-loaded="false">
                                <img src=<?php echo e(asset('/images/icons/dockbar/notification.png'), false); ?> />

                                <span
                                    style="display: unset;position: unset;bottom: unset;left: unset;width: unset;background-color: unset;padding: unset;"
                                    class=" label-warning notifications_count">
                                    <?php if(!empty($total_unread)): ?>
                                        <?php echo e($total_unread, false); ?>

                                    <?php endif; ?>
                                </span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- <li class="header">You have 10 unread notifications</li> -->
                                <li>
                                    <!-- inner menu: contains the actual data -->

                                    <ul style="width: 250px;padding: 10px;" class="menu" id="notifications_list">
                                        <span class="notif-info"
                                            style="display: unset;position: unset;bottom: unset;left: unset;width: unset;background-color: unset;padding: unset;">

                                        </span>
                                    </ul>
                                </li>

                                <?php if(count($all_notifications) > 10): ?>
                                    <li class="footer load_more_li">
                                        <a href="#" class="load_more_notifications"><?php echo app('translator')->get('lang_v1.load_more'); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profit_loss_report.view')): ?>
						<li  type="button" id="view_todays_profit" title="<?php echo e(__('home.todays_profit'), false); ?>" data-toggle="tooltip" data-placement="bottom">
						    <strong><img
								src=<?php echo e(asset('/images/icons/dockbar/cashreg.png'), false); ?> /></strong>
						</li>
					  <?php endif; ?>


                    <?php if(in_array('pos_sale', $enabled_modules)): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sell.create')): ?>
						<li title="<?php echo app('translator')->get('lang_v1.dock_products'); ?>" style="margin-right: 2px;margin-left: 2px;">
                            <a href="<?php echo e(action('SellPosController@create'), false); ?>" title="<?php echo app('translator')->get('sale.pos_sale'); ?>"
                                data-toggle="tooltip" data-placement="bottom" >
                                <strong> <img
									src=<?php echo e(asset('/images/icons/dockbar/casher.png'), false); ?> /></strong>
                            </a>
						</li>
                        <?php endif; ?>
                    <?php endif; ?>





                    </ul>
                </div>

            </div>

        </div>
    </div>



      </div>
    </nav>
	<script>


		function topFunction() {
	  document.body.scrollTop = 0; // For Safari
	  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
	}
	</script>

  </header>
<?php /**PATH /home/onoo/public_html/erpdev/resources/views/layouts/partials/header.blade.php ENDPATH**/ ?>